from django.apps import AppConfig

class NMConfig(AppConfig):
    name='NM'